<!DOCTYPE html>
<meta charset="UTF-8">
<html lang="pl">
    <title>Port Lotniczy</title>
    <link rel="stylesheet" href="styl5.css">
    <head>

    </head>
    <body>
        <header>
            <section id="baner1">
            <img src="zad5.png" alt="logo lotnisko" height="200px">
            </section>
            <section id="baner2">
                <h1>Przyloty</h1>
            </section>
            <section id="baner3">
                <h3>przydatne linki</h3>
                <a href="kwerendy.txt">kwerendy</a>
            </section>
        </header>
        <main>
            <section id="main">
                <table>
                <tr>
                    <th>czas</th>
                    <th>kierunek</th>
                    <th>numer rejsu</th>
                    <th>status</th>
                </tr>
                <?php
                    $conn = new mysqli("localhost","root","","egzamin");

                    $sql = "SELECT czas, kierunek, nr_rejsu, status_lotu FROM przyloty ORDER BY czas ASC;";
                    $result = $conn->query($sql);

                    while($row = $result -> fetch_array()) {
                        echo "<tr>";
                            echo "<td>$row[0]</td>";
                            echo "<td>$row[1]</td>";
                            echo "<td>$row[2]</td>";
                            echo "<td>$row[3]</td>";
                        echo "</tr>";
                    }

                    $conn -> close();
                ?>
            </table>
            </div>
        </main>
        <footer>
            <section id="blok1">
                <?php
            if(isset($_COOKIE['visited'])) {
                echo "<p><i>Witaj ponownie na stronie lotniska!</i></p>";
            }
            else {
                echo "<p><b>Dzień dobry! Strona lotniska używa ciasteczek.</b></p>";
                setcookie("visited", "true", time() + 7200);
            }
        ?>
            </section>
            <section id="blok2">
                <h4>autor: aisfsohfdoshgs</h4>
            </section>
        </footer>
    </body>
</html>