<!DOCTYPE html>
<html lang="pl">
    <head>
        <meta charset="UTF-8" width="640px"> 
        <title>Motocykle</title>
        <link rel="stylesheet" href="styl.css">
    </head>
    <body>
        <img src="motor.png" alt="motocykl">
        
        <header>
            <h1>Motocykle - moja pasja</h1>
        </header>

        <main>
            <h2>Gdzie pojechać?</h2>
            <?php
            $conn = new mysqli("localhost", "root", "", "motory");
                $sql = "SELECT nazwa, opis, poczatek, zrodlo FROM wycieczki JOIN zdjecia ON zdjecia_id = zdjecia.id;";
                $wynik = $conn->query(query: $sql);
                while($row = $wynik -> fetch_array()) {
                    echo "<section class='terminy'>";
                        echo "$row[0], rozpoczyna się w $row[2], <a href='$row[3].jpg'>zobacz zdjęcie</a>";
                    echo "</section>";
                    echo "<section class='opis'>";
                        echo $row[1];
                    echo "</section>";
                }
            ?>
        </main>

        <section id="prawy-górny">
            <h2>Co kupić?</h2>
            <ol>
                <li>Honda CBR125R</li>
                <li>Yamaha YBR125</li>
                <li>Honda VFR800i</li>
                <li>Honda CBR1100XX</li>
                <li>BMW R1200GS LC</li>
            </ol>
        </section>

        <section id="prawy-dolny">
            <h2>Statystyki</h2>
            <?php
                $sql = "SELECT COUNT(*) FROM wycieczki;";
                $wynik = $conn->query(query: $sql);
                while($row = $wynik -> fetch_array()) {
                    $liczba = $row[0];
                }
                echo "<p>Wpisanych wycieczek: $liczba</p>";
                $conn -> close();
            ?>
            <p>Użytkowników forum: 200</p>
            <p>Przesłanych zdjęć: 1300</p>
        </section>

        <footer>
            <p>Stronę wykonał: asdafhaifaia</p>
        </footer>

    </body>
</html>
